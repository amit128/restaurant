
const mongoose = require('mongoose');
const users = mongoose.model('users');

const login=function(req,res){
    users
        .find()
        .exec((err, dataplace) => {
            if (err) {
                res
                    .status(200)
                    .json(err)
                return;
            }

            res
                .status(200)
                .json({
                    'status': 'success',
                    'data': dataplace
                })
        })
};

module.exports=
{
    login
};
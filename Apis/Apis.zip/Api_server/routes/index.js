var express = require('express');
var router = express.Router();

const ctrlMain=require("../controllers/login");

/* GET home page. */
router.get('/login', ctrlMain.login);

module.exports = router;
